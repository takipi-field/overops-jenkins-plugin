package com.takipi.common.api.result.category;

import com.takipi.common.api.result.intf.ApiResult;

public class CreateCategoryResult implements ApiResult {
	public String category_id;
}
