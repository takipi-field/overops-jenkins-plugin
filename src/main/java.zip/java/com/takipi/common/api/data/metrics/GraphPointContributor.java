package com.takipi.common.api.data.metrics;

public class GraphPointContributor {
	public String id;
	public long value;
}
