package com.takipi.common.api.data.view.filter;

public class FirstSeenFilter {
	public AbsFirstSeenFilter absolute;
	public String relative;
}
