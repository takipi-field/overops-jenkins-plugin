package com.takipi.common.api.data.event;

public class Location {
	public String prettified_name;
	public String class_name;
	public String method_name;
	public String method_desc;
}
