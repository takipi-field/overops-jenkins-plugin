package com.takipi.common.api.data.metrics;

import java.util.List;

public class Graph {
	public String type;
	public String id;
	public List<GraphPoint> points;
}
