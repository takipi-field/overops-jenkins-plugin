package com.takipi.common.api.result.intf;

public interface ApiResult {

}
