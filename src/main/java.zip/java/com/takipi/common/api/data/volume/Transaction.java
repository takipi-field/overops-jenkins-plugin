package com.takipi.common.api.data.volume;

public class Transaction {
	public String name;
	public Stats stats;
}
