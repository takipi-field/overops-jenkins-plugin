package com.takipi.common.api.data.view.filter;

public class AbsFirstSeenFilter {
	public String from;
	public String to;
}
