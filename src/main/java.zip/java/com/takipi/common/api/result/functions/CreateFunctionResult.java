package com.takipi.common.api.result.functions;

import com.takipi.common.api.data.functions.UserLibrary;
import com.takipi.common.api.result.intf.ApiResult;

public class CreateFunctionResult implements ApiResult {
	public UserLibrary library;
}
