package com.takipi.common.api.result.view;

import com.takipi.common.api.result.intf.ApiResult;

public class CreateViewResult implements ApiResult {
	public String view_id;
}
