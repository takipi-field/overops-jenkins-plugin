package com.takipi.common.api.data.functions;

public class UserFunction {
	public String libraryId;
	public String functionId;
	public String type;
	public String functionName;
	public String description;
	public String paramType;
	public String defaultParams;
	public String classFile;
}
