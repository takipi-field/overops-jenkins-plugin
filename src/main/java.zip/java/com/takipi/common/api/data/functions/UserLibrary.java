package com.takipi.common.api.data.functions;

import java.util.List;

public class UserLibrary {
	public String id;
	public String version;
	public String name;
	public String scope;
	public String key;
	public List<UserFunction> functions;
}
