package com.takipi.common.api.result;

import com.takipi.common.api.result.intf.ApiResult;

public class GenericResult implements ApiResult {
	public boolean result;
	public String message;
}
