package com.takipi.common.api.result;

import com.takipi.common.api.result.intf.ApiResult;

public class EmptyResult implements ApiResult {

}
