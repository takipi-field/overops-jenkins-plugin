package com.takipi.common.api.result.event.actions;

import java.util.List;
import com.takipi.common.api.result.intf.ApiResult;

public class EventsActionsResult implements ApiResult {
	public List<EventActionsResult> events;
}
