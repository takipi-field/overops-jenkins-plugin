package com.takipi.common.api.data.deployment;

public class SummarizedDeployment {
	public String name;
}
