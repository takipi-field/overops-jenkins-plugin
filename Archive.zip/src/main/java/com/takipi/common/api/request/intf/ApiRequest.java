package com.takipi.common.api.request.intf;

public interface ApiRequest {
	public String urlPath();

	public String contentType();
}
