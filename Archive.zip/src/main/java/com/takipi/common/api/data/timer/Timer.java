package com.takipi.common.api.data.timer;

import java.util.List;

public class Timer {
	public String id;
	public String class_name;
	public String method_name;
	public long threshold;
	public List<String> servers;
	public List<String> applications;
}
