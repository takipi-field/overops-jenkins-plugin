package com.takipi.common.api.result.event;

import com.takipi.common.api.result.intf.ApiResult;

public class EventSnapshotResult implements ApiResult {
	public String link;
}
