package com.takipi.common.api.data.volume;

public class Stats {
	public long hits;
	public long invocations;
	public double avg_time;
}
