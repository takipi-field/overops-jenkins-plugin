package com.takipi.common.api.result.functions;

import java.util.List;

import com.takipi.common.api.data.functions.UserLibrary;
import com.takipi.common.api.result.intf.ApiResult;

public class FunctionsResult implements ApiResult {
	public List<UserLibrary> libraries;
}
