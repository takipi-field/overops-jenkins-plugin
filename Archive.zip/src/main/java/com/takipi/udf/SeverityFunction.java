package com.takipi.udf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import com.google.gson.Gson;
import com.takipi.common.api.ApiClient;
import com.takipi.common.api.data.label.Label;
import com.takipi.common.api.data.view.SummarizedView;
import com.takipi.common.api.data.view.ViewFilters;
import com.takipi.common.api.data.view.ViewInfo;
import com.takipi.common.api.request.event.EventModifyLabelsRequest;
import com.takipi.common.api.request.event.actions.EventActionsRequest;
import com.takipi.common.api.request.label.CreateLabelRequest;
import com.takipi.common.api.request.label.LabelsRequest;
import com.takipi.common.api.request.view.CreateViewRequest;
import com.takipi.common.api.request.view.ViewsRequest;
import com.takipi.common.api.request.volume.EventsVolumeRequest;
import com.takipi.common.api.result.EmptyResult;
import com.takipi.common.api.result.event.EventResult;
import com.takipi.common.api.result.event.actions.EventActionsResult;
import com.takipi.common.api.result.event.actions.EventsActionsResult;
import com.takipi.common.api.result.label.LabelsResult;
import com.takipi.common.api.result.view.CreateViewResult;
import com.takipi.common.api.result.view.ViewsResult;
import com.takipi.common.api.result.volume.EventsVolumeResult;
import com.takipi.common.api.url.UrlClient.Response;
import com.takipi.common.api.util.Pair;
import com.takipi.common.api.util.ValidationUtil.VolumeType;
import com.takipi.common.udf.ContextArgs;
import com.takipi.common.udf.input.Input;
import com.takipi.common.udf.label.ApplyLabelFunction;

public class SeverityFunction {

	//control whether to actually apply labels etc or just sysout
	public static boolean MUTATE_DB = false;
	
	static class SeverityInput extends Input {
		public int activeTimespan; // the time window (min) that we compare the baseline to
		public int baseTimespan; // the time window (min) to compare the last <activeTimespan> against
		public double reggressionDelta; //a change in % that would be considered a regression
		public String criticalExceptionTypes; //comma delimited list of exception types that are severe by def
		public double minErrorRateThreshold; //min ER that a regression, new + non-critical event must exceed
		public int minVolumeThreshold; //min volume that a regression, new + non-critical event must exceed
		public String newEventslabel; //how to label new issues
		public String regressedEventsLabel; // how to label regressions
		public String newEventsView; //view containing new issues
		public String regressedEventsView; // view containing regressions
		public int labelRetention; // how long (min) should thse labels "stick" to an event

		private SeverityInput(String raw) {
			super(raw);
		}

		static SeverityInput of(String raw) {
			return new SeverityInput(raw);
		}
	}
		
	public static void main(String[] args) {
		
		ContextArgs contextArgs = new ContextArgs();
		
		contextArgs.apiHost = "https://api.overops.com";
		
		//remove these before uploading to GH
		contextArgs.apiKey = "2RUD8JJA3yJ202Vv2LB+eb8UckRx+lLcodXhKHKL";
		contextArgs.serviceId = "S6295";
		contextArgs.viewId = "P283";
		
		//some test values to play with
		String[] values = new String[] {
				"activeTimespan=60",  
				"baseTimespan=10080", //week
				"reggressionDelta=0.1", 
				"criticalExceptionTypes=NullPointerException,IndexOutOfBoundsException,ClassCastException, AssertionError", 
				"minErrorRateThreshold=0.1", 
				"minVolumeThreshold=100", 
				"newEventslabel=New Issue", 
				"regressedEventsLabel=Regression", 
				"newEventsView=New Issues", 
				"regressedEventsView=Regressions", 
				"labelRetention=1440"
			};	
		
		SeverityInput input = new SeverityInput(String.join("\n", values)); 
		
		execute(contextArgs, input);

	}
	
	public static void execute(String rawContextArgs, SeverityInput input) {
		ContextArgs args = (new Gson()).fromJson(rawContextArgs, ContextArgs.class);
		
		System.out.println("execute:" + rawContextArgs);

		
		if (!args.viewValidate()) {
			throw new IllegalArgumentException("Bad context args - " + rawContextArgs);
		}
		
		execute(args, input);
	}
	
	public static void createLabelViewsIfNotExists(ContextArgs args, Collection<Pair<String, String>> viewsAndLabels) {
		
		Map<String, SummarizedView> views = getServiceViews(args);
		
		for (Pair<String, String> pair : viewsAndLabels) {
		
			String viewName = pair.getFirst();
			String labelName = pair.getSecond();
			
			SummarizedView view = views.get(viewName);
			
			if (views.containsKey(viewName)) {
				System.out.println("views " + viewName + " found with ID " + view.id);
	
				return;
			}
			
			ViewInfo viewInfo = new ViewInfo();
			
			viewInfo.name = viewName;
			viewInfo.filters = new ViewFilters();
			viewInfo.filters.labels = Collections.singletonList(labelName);
			
			CreateViewRequest createViewRequest = CreateViewRequest.newBuilder().setServiceId(args.serviceId).setViewInfo(viewInfo).build();
			
			Response<CreateViewResult> viewResponse = args.apiClient().post(createViewRequest);
			
			if ((viewResponse.isBadResponse()) || (viewResponse.data == null)) {
				System.err.println("Cannot create view " + viewName);
			} else {
				System.out.println("Created view " + viewResponse.data.view_id + " for label " + labelName);
			}
		}
	}
	
	public static void createLabelsIfNotExists(ContextArgs args, String[] labelNames) {
			
		Map<String, Label> existingLabels = getServiceLabels(args);	
		
		for (String labelName: labelNames) {
		
			Label label = existingLabels.get(labelName);
	
				if (label != null) {
					System.out.println("label " + labelName + " found");
	
					return;
				}
				
				CreateLabelRequest createLabelRequest = CreateLabelRequest.newBuilder().setServiceId(args.serviceId).setName(labelName).build();
				
				Response<EmptyResult> labelResponse = args.apiClient().post(createLabelRequest);
				
				if (labelResponse.isBadResponse()) {
					System.err.println("Cannot create label " + labelName);
				} 
			}
		}
		
	
	public static Map<String, SummarizedView> getServiceViews(ContextArgs args) {
		
		Map<String, SummarizedView> result = new HashMap<String, SummarizedView>();
		
		ViewsRequest viewsRequest = ViewsRequest.newBuilder().setServiceId(args.serviceId).build();
		
		Response<ViewsResult> viewsResponse = args.apiClient().get(viewsRequest);

		if ((viewsResponse.isBadResponse()) || (viewsResponse.data == null) ||
			(viewsResponse.data.views == null)) {
			System.err.println("Can't list views");
		}
			
		for (SummarizedView view :  viewsResponse.data.views) {
			result.put(view.name, view);
		}

		return result;
	}
	
public static Map<String, Label> getServiceLabels(ContextArgs args) {
		
		Map<String, Label> result = new HashMap<String, Label>();
		
		LabelsRequest viewsRequest = LabelsRequest.newBuilder().setServiceId(args.serviceId).build();
		
		Response<LabelsResult> labelsResponse = args.apiClient().get(viewsRequest);

		if ((labelsResponse.isBadResponse()) || (labelsResponse.data == null) ||
			(labelsResponse.data.labels == null)) {
			System.err.println("Can't list labels");
		}
			
		for (Label label :  labelsResponse.data.labels) {
			result.put(label.name, label);
		}

		return result;
	}
	
	public static void execute(ContextArgs args, SeverityInput input) {
		
		createLabelsIfNotExists(args, new String[] { input.newEventslabel, input.regressedEventsLabel });

		Collection<Pair<String, String>> views = new ArrayList<Pair<String, String>>();

		views.add(Pair.of(input.newEventsView, input.newEventslabel));
		views.add(Pair.of(input.regressedEventsView, input.regressedEventsLabel));

		createLabelViewsIfNotExists(args, views);

		//get the event data for time window  we're looking to spot regressions in
		EventsVolumeResult activeEventVolume = getEventVolume(args, input.activeTimespan);
		
		//get the event data for time window we're comparing regressions against
		EventsVolumeResult baselineEventVolume = getEventVolume(args, input.baseTimespan);
		
		//prep some helper maps
		Map<String, EventResult> regressionMap = new HashMap<String, EventResult>();
		Map<String, EventResult> newEventsMap = new HashMap<String, EventResult>();
		Map<String, EventResult> baseLineMap = new HashMap<String, EventResult>();
		
		//prep the list of event types that don't require a min threshold for new events. 
		Set<String> criticalExceptionTypes = new HashSet<String>(Arrays.asList(StringUtils.split(input.criticalExceptionTypes)));
		
		for (EventResult eventResult : baselineEventVolume.events) {
			
			if (eventResult.stats == null) {
				continue;
			}
			
			baseLineMap.put(eventResult.id, eventResult);
		}
		
		for (EventResult activeEventResult : activeEventVolume.events) {
			EventResult baseLineEventResult = baseLineMap.get(activeEventResult.id);
			
			boolean isUncaught = false; //TBD: extract this from event, once API avail
			
			//events types in the critical list are considered as new regardless of threshold
			if ((criticalExceptionTypes.contains(activeEventResult.type)) ||(isUncaught)) {
				newEventsMap.put(activeEventResult.id, activeEventResult);
				
				System.out.println("Event " + activeEventResult.id + " " 
						+ activeEventResult.type + " is critical with " + activeEventResult.stats.hits);	
				continue;
			}
			
			if (baseLineEventResult == null) {
				continue;
			}
			
			if (activeEventResult.stats == null) {
				continue;
			}
			
			if ((activeEventResult.stats.invocations == 0) || (activeEventResult.stats.hits == 0)) {
				continue;
			}
			
			double activeEventRatio = ((double)activeEventResult.stats.hits /  (double)activeEventResult.stats.invocations);
			
			//if below min thresholds - skip
			if ((activeEventRatio < input.minErrorRateThreshold) 
			|| (activeEventResult.stats.hits < input.minVolumeThreshold)) {
				continue;
			}
						
			DateTime firstSeen = ISODateTimeFormat.dateTimeParser().parseDateTime(activeEventResult.first_seen);
			DateTime compareWindow = DateTime.now().minusMinutes(input.baseTimespan);

			//if newer than baseline - mark
			if (firstSeen.isAfter(compareWindow)) {
				newEventsMap.put(activeEventResult.id, activeEventResult);
				
				System.out.println("Event " + activeEventResult.id + " " 
						+ activeEventResult.type + " is new with ER: " + activeEventRatio 
						+ " hits: " + activeEventResult.stats.hits);
			}
			
			//see what the error rate is for the event
			double baselineEventRatio;
			
			if (baseLineEventResult.stats.invocations > 0) {
				baselineEventRatio = (double)baseLineEventResult.stats.hits /  (double)baseLineEventResult.stats.invocations;
			} else {
				baselineEventRatio = 0;
			}
			
			boolean regression;
			
			if (baselineEventRatio == 0)
			{
				regression = true;
			} else {
				//see if the error rate has increased by more than X%, if so an above min volume, mark as regression
				regression = activeEventRatio - baselineEventRatio >= input.reggressionDelta;		
			}
			
			if (regression) {
				
				regressionMap.put(activeEventResult.id, activeEventResult);
				
				System.out.println("Event " + activeEventResult.id + " " 
					+ activeEventResult.type + " regressed from ER: " + baselineEventRatio + " to: " + activeEventRatio 
					+ " hits: " + activeEventResult.stats.hits);
			}
		}
		
		//apply the "New Issue" and "Regression" labels to each of the lists
		applyLabels(args, input.newEventslabel, input.labelRetention, newEventsMap, baseLineMap);
		applyLabels(args, input.regressedEventsLabel, input.labelRetention, regressionMap, baseLineMap);		
	}
	
	private static void applyLabels(ContextArgs args, String label, int labelRetention, 
			Map<String, EventResult> targetEvents, Map<String, EventResult> allEvents) {
		
		ApiClient apiClient = args.apiClient();
		
		ContextArgs eventArgs = new ContextArgs();
		eventArgs.apiHost = args.apiHost;
		eventArgs.apiKey = args.apiKey;
		eventArgs.serviceId = args.serviceId;
		
		String applyLabelParams = "label=" + label;
		
		Map<String, EventResult> newlyLabeledEvents = new HashMap<String, EventResult>();
				
		for (EventResult event : targetEvents.values()) {
			
			boolean hasLabel = (event.labels != null) && (event.labels.contains(label));
			
			if (!hasLabel)
			{
				//let's leverage the existing Apply Label UDF
				args.eventId = event.id;
				newlyLabeledEvents.put(event.id, event);
				
				if (MUTATE_DB) {
					ApplyLabelFunction.execute(new Gson().toJson(eventArgs), applyLabelParams);
				}
				
				System.out.println("Applying label " + label + " to " + event.id);
			}
		}
		
		for (EventResult event : allEvents.values()) {
			
			//if this is a new severe issue, no need to cleanup its label
			if (newlyLabeledEvents.containsKey(event.id)) {
				continue;
			}
			
			// if this event wasn't prev marked as severe - skip
			if ((event.labels == null) && (!event.labels.contains(label))) {
				continue;
			}
			
			//get the actions for this event. Let's see when was that event marked severe
			EventActionsRequest eventActionsRequest = EventActionsRequest.newBuilder().setServiceId(args.serviceId)
					.setEventId(event.id).build();
			
			Response<EventsActionsResult> eventsActionsResponse = apiClient.get(eventActionsRequest);

			if (eventsActionsResponse.isBadResponse()) {
				System.err.println("Can't create events actions for event " + event.id);
			}

			if (eventsActionsResponse.data.events == null) {
				continue;
			}
			
			for (EventActionsResult eventAction : eventsActionsResponse.data.events) {
				
				//we should add a constant for this in the Java API wrapper
				if (!"Add Label".equals(eventAction.action)) {
					continue;
				}
				
				if (!label.equals(eventAction.data)) {
					continue;
				}
				
				DateTime labelAddTime = ISODateTimeFormat.dateTimeParser().parseDateTime(eventAction.timestamp);
				DateTime retentionWindow = DateTime.now().minusMinutes(labelRetention);

				//lets see if the label was added before the retention window, is so - remove it 
				if (labelAddTime.isBefore(retentionWindow)) {
					
					if (MUTATE_DB) {
						EventModifyLabelsRequest eventModifyLabelsRequest = EventModifyLabelsRequest.newBuilder().setServiceId(args.serviceId)
								.setEventId(event.id).removeLabel(label).build();
						
						Response<EmptyResult> eventModifyLabelsResponse = apiClient.post(eventModifyLabelsRequest);
						
						if (eventModifyLabelsResponse.isBadResponse()) {
							System.err.println("Can't remove label " + label + " for event " + event.id);
						}	
					}
					
					System.out.println("Removing label " + label + " from " + event.id);
				}
			}
		}
		
		
	}

	public static EventsVolumeResult getEventVolume(ContextArgs args, int timeSpan) {
		ApiClient apiClient = args.apiClient();

		DateTime to = DateTime.now();
		DateTime from = to.minusMinutes(timeSpan);

		DateTimeFormatter fmt = ISODateTimeFormat.dateTime().withZoneUTC();

		EventsVolumeRequest eventsVolumeRequest = EventsVolumeRequest.newBuilder().setServiceId(args.serviceId)
				.setViewId(args.viewId).setFrom(from.toString(fmt)).setTo(to.toString(fmt)).setVolumeType(VolumeType.all)
				.build();

		Response<EventsVolumeResult> eventsVolumeResponse = apiClient.get(eventsVolumeRequest);

		if (eventsVolumeResponse.isBadResponse()) {
			throw new IllegalStateException("Can't create events volume.");
		}

		EventsVolumeResult eventsVolumeResult = eventsVolumeResponse.data;

		if (eventsVolumeResult == null) {
			throw new IllegalStateException("Missing events volume result.");
		}

		if (eventsVolumeResult.events == null) {
			throw new IllegalStateException("Missing events volume event data.");
		}
		
		return eventsVolumeResult;
	}
}
